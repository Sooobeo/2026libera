"""Three serial synthetic latency probes; never pilot/main research responses.

This uses engineering settings, not paper conditions. Each configuration gets
one generation attempt, without retries. Existing installed manifests are pinned;
no model is pulled and no research runtime, evaluation or freeze file is changed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

import remote_sector_runtime as remote

ROOT = Path(__file__).resolve().parents[1]
ENGINE = '0.35.1'
MODELS = {
    'qwen3.5:4b-q4_K_M':'d8b0f5e9760cd1682034f292d7ef72ec46f432149be0df7574bf2d6e92e38c04',
    'qwen3:1.7b':'8f68893c685c3ddff2aa3fffce2aa60a30bb2da65ca488b61fff134a4d1730e7',
}
PROBES = [('4b_threads2','qwen3.5:4b-q4_K_M',2),
          ('4b_threads4','qwen3.5:4b-q4_K_M',4),
          ('1p7b_threads2','qwen3:1.7b',2)]
PROMPT = (
    'This is a synthetic latency check, not an investment task. Read these fictional inventory records. '
    'Do not summarize or analyze them. After the records, return only the requested JSON.\n' +
    ''.join(f'item={i:02}; group=amber; units=07; note=synthetic fixture.\n' for i in range(1,16)) +
    '\nReturn exactly this JSON object, without commentary: {"ready":true}\n'
)


def body_for(model, threads):
    return {'model':model,'messages':[{'role':'user','content':PROMPT}],
            'stream':True,'think':False,'format':'json','keep_alive':0,
            'options':{'temperature':0,'num_ctx':8192,'num_predict':32,'num_thread':threads,
                       'num_batch':512,'repeat_penalty':1.0,'presence_penalty':0.0,
                       'frequency_penalty':0.0,'seed':3407}}


def observe(origin, model, previous=None):
    version = remote.api_json(origin,'/api/version')
    tags = remote.api_json(origin,'/api/tags')
    selected = [m for m in tags.get('models',[]) if m.get('name')==model]
    if version.get('version')!=ENGINE or len(selected)!=1:
        raise RuntimeError('Exact installed model and engine pins are required; no substitution')
    if selected[0].get('digest','').removeprefix('sha256:')!=MODELS[model]:
        raise RuntimeError('Installed manifest differs from the approved existing digest')
    show = remote.api_json(origin,'/api/show',{'model':model})
    template = show.get('template')
    if not isinstance(template,str):raise RuntimeError('Model template was not observed')
    value = {'version':version,'selected_model':selected[0],'show':show,
             'template_sha256':hashlib.sha256(template.encode()).hexdigest()}
    if previous and value['template_sha256']!=previous['template_sha256']:
        raise RuntimeError('Model template changed between probes')
    return value


def unload_and_confirm(origin, model):
    # Use the explicitly selected model, never the coordinator's module MODEL.
    unloaded = remote.optional_api(origin,'/api/generate',{'model':model,'keep_alive':0},timeout=5)
    observations = []
    for _ in range(3):
        state = remote.optional_api(origin,'/api/ps',timeout=2)
        observations.append(state)
        if state.get('status')=='ok' and not state.get('value',{}).get('models'):
            return {'status':'no_resident_models_observed','unload':unloaded,'ps':observations}
        time.sleep(0.2)
    return {'status':'idle_not_confirmed','unload':unloaded,'ps':observations}


def worker(spec_path):
    spec = remote.read(spec_path); target = Path(spec_path).parent
    session = remote.Session(target,spec['origin'],timeout_seconds=spec['deadline_seconds'],monitor_seconds=2)
    started = time.monotonic(); outcome = {'status':'attempted','model_requests_attempted':1}
    try:
        session.start_monitor()
        response = remote.stream_call(session,'/api/chat',spec['body'],'latency_probe')
        content = response.get('message',{}).get('content','')
        try: parsed = json.loads(content); json_ok = isinstance(parsed,dict)
        except (ValueError,TypeError): parsed = None; json_ok = False
        matching_model=response.get('model')==spec['body']['model']
        thinking=bool(response.get('message',{}).get('thinking'))
        status=('output_limit_reached' if response.get('done_reason')=='length' else
                'response_protocol_anomaly' if thinking or not matching_model else 'completed')
        outcome.update(status=status,done_reason=response.get('done_reason'),
                       parseable_json_object=json_ok,unexpected_thinking=bool(response.get('message',{}).get('thinking')),
                       expected_synthetic_json=parsed=={'ready':True},response_model=response.get('model'))
    except remote.RemoteCallError as exc:
        outcome.update(status=exc.result.get('status','failed'),error=str(exc))
    except BaseException as exc:
        outcome.update(status='cancelled' if isinstance(exc,KeyboardInterrupt) else 'failed',
                       error_type=type(exc).__name__,error=str(exc))
    finally:
        session.stop_monitor()
        outcome.update(worker_wall_seconds=time.monotonic()-started,calls=session.calls,
                       model_requests_attempted=len(session.calls),
                       pilot_model_calls=0,main_model_calls=0,automatic_retries=0)
        remote.save(target/'worker_summary.json',outcome)
    return 0 if outcome['status']=='completed' else 1


def supervised_worker(spec_path, deadline, cancel_path):
    """A separate process bounds connect, headers and streaming, not only reads."""
    target = Path(spec_path).parent; started = time.monotonic()
    with (target/'worker.console.log').open('xb') as log:
        process = subprocess.Popen([sys.executable,'-B',str(Path(__file__).resolve()),'--worker',str(spec_path)],
                                   stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
        stopped = None
        try:
            while process.poll() is None:
                remaining = deadline-(time.monotonic()-started)
                if Path(cancel_path).exists():stopped='cancelled';break
                if remaining<=0:stopped='hard_deadline';break
                time.sleep(min(0.05,remaining))
        except KeyboardInterrupt:
            stopped='cancelled'
        if stopped:
            # SIGKILL/TerminateProcess closes this client's sockets; do not kill Ollama.
            process.kill()
            process.wait(timeout=3)
        else:process.wait()
    result = {'supervisor_status':stopped or 'worker_exited','worker_exit_code':process.returncode,
              'elapsed_seconds':time.monotonic()-started,'deadline_seconds':deadline,
              'deadline_scope':'Child process lifetime includes setup, connect, headers and complete stream; OS scheduling/kill overhead is separately included in elapsed_seconds.',
              'automatic_retries':0}
    if (target/'worker_summary.json').is_file():result['worker']=remote.read(target/'worker_summary.json')
    else:result['worker_summary_missing']=True
    remote.save(target/'supervisor_result.json',result)
    return result


def run(args):
    origin = remote.validate_origin(args.base_url)
    if not 1<=args.deadline_seconds<=120:raise ValueError('Each probe deadline must be 1..120 seconds')
    target = remote.new_output(args.output_root,'latency',args.run_id)
    planned = [{'probe_id':label,'model':model,'threads':threads,'status':'not_started'} for label,model,threads in PROBES]
    remote.save(target/'invocation.json',{
        'scope':'Synthetic engineering latency diagnosis; excluded from research pilot/main and evaluation.',
        'started_at_utc':remote.now(),'origin':origin,'deadline_seconds':args.deadline_seconds,
        'script_sha256':remote.sha(Path(__file__)),'coordinator_sha256':remote.sha(Path(remote.__file__)),
        'prompt_characters':len(PROMPT),'prompt_utf8_bytes':len(PROMPT.encode()),
        'prompt_sha256':hashlib.sha256(PROMPT.encode()).hexdigest(),'planned_probes':planned,
        'condition_basis':'8192 context, output cap32, T0, disabled thinking, batch512, neutral repeat/presence/frequency penalties, seed3407, thread counts and deadline are engineering controls for these latency probes; this is not a paper-derived experiment even where a number also appears in a paper.',
        'comparison_limits':'One fixed-order attempt per configuration; unload does not evict OS file cache. Model/template/tokenizer differ. No statistical speed ranking or four-stage feasibility verdict.',
        'pilot_model_calls':0,'main_model_calls':0})
    (target/'prompt.txt').write_text(PROMPT,encoding='utf-8')
    pinned = {}; attempted = 0; overall = 'completed'
    try:
        # Existing other workloads must be stopped by the operator before this diagnostic.
        state = remote.api_json(origin,'/api/ps')
        remote.save(target/'residency_before.json',state)
        if state.get('models'):raise RuntimeError('Ollama is already resident/busy; stop the earlier run before these serial probes')
        for row in planned:
            if (target/'CANCEL').exists():overall='cancelled';break
            folder = target/row['probe_id'];folder.mkdir()
            observed = observe(origin,row['model'],pinned.get(row['model']))
            pinned.setdefault(row['model'],observed)
            remote.save(folder/'model_observation.json',observed)
            spec = {'origin':origin,'deadline_seconds':args.deadline_seconds,'body':body_for(row['model'],row['threads'])}
            remote.save(folder/'worker_spec.json',spec)
            row['status']='attempted';attempted+=1
            result = supervised_worker(folder/'worker_spec.json',args.deadline_seconds,target/'CANCEL')
            row.update(status=result.get('worker',{}).get('status',result['supervisor_status']),
                       supervisor_status=result['supervisor_status'],elapsed_seconds=result['elapsed_seconds'])
            http_folder=folder/'http_0001_latency_probe'
            row['generation_request_recorded']=(http_folder/'request.json').is_file()
            call_result=remote.read(http_folder/'result.json') if (http_folder/'result.json').is_file() else {}
            row['provider_metrics']=call_result.get('metrics')
            row['prompt_eval_count']=(row['provider_metrics'] or {}).get('prompt_eval_count')
            row['eval_count']=(row['provider_metrics'] or {}).get('eval_count')
            row['response_assessment']=({key:result['worker'].get(key) for key in
                ('parseable_json_object','expected_synthetic_json','unexpected_thinking','response_model','done_reason')}
                if result.get('worker') else None)
            cleanup = unload_and_confirm(origin,row['model'])
            remote.save(folder/'unload_and_residency.json',cleanup)
            if cleanup['status']!='no_resident_models_observed':
                overall='stopped_idle_not_confirmed';break
            if result['supervisor_status']=='cancelled':overall='cancelled';break
        if overall=='completed' and any(row['status']!='completed' for row in planned):overall='completed_with_probe_failures'
    except BaseException as exc:
        overall='cancelled' if isinstance(exc,KeyboardInterrupt) else 'stopped_before_or_between_probes'
        remote.save(target/'failure.json',{'type':type(exc).__name__,'message':str(exc)})
    result = {'status':overall,'finished_at_utc':remote.now(),'probe_invocations_attempted':attempted,
              'completed_probes':sum(row['status']=='completed' for row in planned),
              'generation_request_envelopes_recorded':sum(row.get('generation_request_recorded',False) for row in planned),
              'not_started_probes':sum(row['status']=='not_started' for row in planned),
              'records':planned,'pilot_model_calls':0,'main_model_calls':0,
              'scope':'Engineering latency probes only; never merged into research responses.',
              'output':str(target)}
    remote.save(target/'summary.json',result)
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
    return 0 if overall in ('completed','completed_with_probe_failures') else 1


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base-url',default='http://127.0.0.1:11434')
    parser.add_argument('--output-root',type=Path,default=ROOT/'data/sector_runtime')
    parser.add_argument('--run-id')
    parser.add_argument('--deadline-seconds',type=float,default=120)
    parser.add_argument('--worker',type=Path,help=argparse.SUPPRESS)
    args=parser.parse_args(argv)
    return worker(args.worker) if args.worker else run(args)


if __name__=='__main__':raise SystemExit(main())
